# Example: Sep 01 2023   
   
Here is an example journal entry from the Anyteam, partially completed. The template for this entry can be found and edited in the *Library* > *Daily Journal *page. Each new journal entry you create will automatically populate to the correct month in the *Daily Journals *set.    
   
**Top 3 Prios for the day:**   
  - [ ] Prio 1   
  - [ ] Prio 2   
  - [ ] Prio 3   
   
**Photo of the Day:**   
   
