# 13. GraphQL   
[Apollo](apollo.md)    
[GraphQL Roadmap](https://roadmap.sh/graphql)    
