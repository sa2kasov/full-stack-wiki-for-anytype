# 12. Web Components   
[HTML Templates](html-templates.md)    
[Custom Elements](custom-elements.md)    
[Shadow DOM](shadow-dom.md)    
