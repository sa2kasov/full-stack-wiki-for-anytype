# Scripting   
[Bash Scripting](bash-scripting.md)    
