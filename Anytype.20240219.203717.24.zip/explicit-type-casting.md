# Explicit Type Casting   
