# Microsoft Learn – Cloud Design Patterns   
Learn about design patterns for building reliable, scalable, secure applications in the cloud by walking through examples based on Microsoft Azure.   
