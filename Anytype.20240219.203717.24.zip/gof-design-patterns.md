# GOF Design Patterns   
