# 05. Web Security   
[HTTPS](https_i.md)    
[SSL&amp;TLS](sslandtls.md)    
[CORS](cors_2.md)    
[CSP](csp.md)    
[Server Security](server-security.md)    
[OWASP](owasp.md)    
[Hashing Algorithms](hashing-algorithms.md)    
[API Security Best Practices](https://roadmap.sh/best-practices/api-security)    
