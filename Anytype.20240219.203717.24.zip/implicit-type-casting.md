# Implicit Type Casting   
