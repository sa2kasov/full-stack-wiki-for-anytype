# typeof Operator   
