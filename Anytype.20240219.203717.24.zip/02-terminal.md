# 02. Terminal   
[Process Monitoring](process-monitoring.md)    
[Performance Monitoring](performance-monitoring.md)    
[Networking Tools](networking-tools.md)    
[Text Manipulation](text-manipulation.md)    
[Scripting](scripting.md)    
[Editors](editors.md)    
