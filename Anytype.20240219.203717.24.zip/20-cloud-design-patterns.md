# 20. Cloud Design Patterns   
[Availability](availability.md)    
[Data Management](data-management.md)    
[Design and Implementation](design-and-implementation.md)    
[Management and Monitoring](management-and-monitoring.md)    
[Cloud design patterns - Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/patterns/)    
