# 11. Web Security   
[HTTPS](https.md)    
[CORS](cors.md)    
[Content Security Policy](content-security-policy.md)    
[OWASP Security Risks](owasp-security-risks.md)    
