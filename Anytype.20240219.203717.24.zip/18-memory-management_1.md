# 18. Memory Management   
[Memory Lifecycle](memory-lifecycle.md)    
[Garbage Collection](garbage-collection.md)    
