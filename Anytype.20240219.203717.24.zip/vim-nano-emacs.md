# Vim, Nano, Emacs   
