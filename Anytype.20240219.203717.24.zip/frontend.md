# Frontend   
[Frontend Developer Roadmap: What is Frontend Development?](https://roadmap.sh/frontend)    
[Frontend Performance Best Practices](https://roadmap.sh/best-practices/frontend-performance)    
   
