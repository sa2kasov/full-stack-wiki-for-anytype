# 05. Data Structures   
[Indexed Collections](indexed-collections.md)    
[Keyed Collections](keyed-collections.md)    
[Structured Data (JSON)](structured-data-json.md)    
