# 08. Design and Development Principles   
[GOF Design Patterns](gof-design-patterns.md)    
[Domain Driven Design (DDD)](domain-driven-design-ddd.md)    
[Test Driven Development (TDD)](test-driven-development-tdd.md)    
[CQRS](cqrs.md)    
[Event Sourcing](event-sourcing.md)    
[Software Design and Architecture Roadmap](https://roadmap.sh/software-design-architecture)    
