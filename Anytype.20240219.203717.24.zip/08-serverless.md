# 08. Serverless   
[Cloudflare](cloudflare.md)    
[AWS Lambda](aws-lambda.md)    
[Azure Functions](azure-functions.md)    
[GCP Functions](gcp-functions.md)    
[Vercel](vercel.md)    
[Netlify](netlify.md)    
