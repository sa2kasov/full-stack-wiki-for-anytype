# AI   
[AI and Data Scientist Roadmap](https://roadmap.sh/ai-data-scientist)    
[Prompt Engineering Roadmap - roadmap.sh](https://roadmap.sh/prompt-engineering)    
   
