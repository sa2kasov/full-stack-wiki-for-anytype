# Kubernetes   
[Kubernetes Roadmap - roadmap.sh](https://roadmap.sh/kubernetes)    
