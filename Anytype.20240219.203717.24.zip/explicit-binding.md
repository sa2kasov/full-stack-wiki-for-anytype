# Explicit Binding   
[call](call.md)    
[apply](apply.md)    
[bind](bind.md)    
