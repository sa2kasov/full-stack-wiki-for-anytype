# Tasks   
Tasks collected from everywhere in Anytype   
