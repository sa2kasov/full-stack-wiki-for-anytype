# 14. Working with APIs   
[XMLHttpRequest](xmlhttprequest.md)    
[Fetch](fetch.md)    
