# Defining and Calling Functions   
