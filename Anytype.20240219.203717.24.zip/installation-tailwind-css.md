# Installation - Tailwind CSS   
The simplest and fastest way to get up and running with Tailwind CSS from scratch is with the Tailwind CLI tool.   
