# Delete pre-installed data   
##    
## Details    
 --- 
Remove all pre-installed objects from **Pre-installed** view of All My Objects set when you will be ready.   
   
   
