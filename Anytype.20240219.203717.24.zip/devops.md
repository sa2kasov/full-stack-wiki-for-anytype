# DevOps   
[DevOps Roadmap: Learn to become a DevOps Engineer or SRE](https://roadmap.sh/devops?r=devops-beginner)    
[DevOps Roadmap: Learn to become a DevOps Engineer or SRE](https://roadmap.sh/devops)    
[Software Design and Architecture Roadmap](https://roadmap.sh/software-design-architecture)    
[System Design Roadmap](https://roadmap.sh/system-design)    
