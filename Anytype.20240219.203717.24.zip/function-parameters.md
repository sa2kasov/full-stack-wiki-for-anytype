# Function Parameters   
[Default Parameters](default-parameters.md)    
[Rest Parameters](rest-parameters.md)    
