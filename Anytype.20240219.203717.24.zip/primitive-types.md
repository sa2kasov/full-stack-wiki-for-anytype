# Primitive Types   
[undefined](undefined.md)    
[null](null.md)    
[boolean](boolean_u.md)    
[string](string.md)    
[number](number_5.md)    
[bigint](bigint.md)    
[Symbol](symbol.md)    
