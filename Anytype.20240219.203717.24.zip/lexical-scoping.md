# Lexical Scoping   
