# 16. Building for Scale   
[Observability](observability.md)    
[Types of Scaling: Horizontal vs Vertical Scaling](types-of-scaling-horizontal-vs-vertical-scaling.md)    
[Instrumentation, Monitoring, and Telemetry](instrumentation-monitoring-and-telemetry.md)    
[Migration Strategies](migration-strategies.md)    
[Mitigation Strategies](mitigation-strategies.md)    
