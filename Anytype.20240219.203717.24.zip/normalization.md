# Normalization   
