> Hello from Anytype!    

Here is a note from us to you.   
Feel free to delete it and create your own!    
   
