# 11. Strict Mode   
