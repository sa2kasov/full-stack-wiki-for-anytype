# Anytype Community   
Place to share feedback, write bug reports, and connect with Anytype users from all over the globe!   
