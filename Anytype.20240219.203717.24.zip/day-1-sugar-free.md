# Day 1 - Sugar Free   
   
This is an example of an entry documenting the completion of a habit on a given day, and the results. You can easily add your data through the *Habit Tracker* set by creating a new row. You can create different views for each habit that you're tracking, and add relations for the specific results you'd like to track. Good luck!   
   
