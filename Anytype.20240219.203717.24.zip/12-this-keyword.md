# 12. (this) Keyword   
[in a method](in-a-method.md)    
[in a function](in-a-function.md)    
[using (this) alone](using-this-alone.md)    
[in event handlers](in-event-handlers.md)    
[in arrow functions](in-arrow-functions.md)    
[Explicit Binding](explicit-binding.md)    
[Function Borrowing](function-borrowing.md)    
