# Equality Algorithms   
[isLooselyEqual](islooselyequal.md)    
[isStrictlyEqual](isstrictlyequal.md)    
[SameValueZero](samevaluezero.md)    
[SameValue](samevalue.md)    
