# 04. Type Casting   
[Type Conversion vs Coercion](type-conversion-vs-coercion.md)    
[Explicit Type Casting](explicit-type-casting.md)    
[Implicit Type Casting](implicit-type-casting.md)    
