# 03. Data Types   
[Primitive Types](primitive-types.md)    
[Object](object.md)    
[typeof Operator](typeof-operator.md)    
