# Built-in Objects   
[Boolean](boolean.md)    
[String](string_f.md)    
[Number](number.md)    
[Math](math.md)    
[Date](date.md)    
[Function](function.md)    
[Error](error.md)    
