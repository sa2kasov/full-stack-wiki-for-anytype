# JavaScript   
[Introduction to JavaScript](introduction-to-javascript.md)    
[Variables](variables.md)    
[Data Types](data-types.md)    
[JavaScript Developer Roadmap: Step by step guide to learn JavaScript](https://roadmap.sh/javascript)    
   
   
