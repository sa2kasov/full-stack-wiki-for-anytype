# Electron Documentation – Build cross-platform desktop apps with JavaScript, HTML, and CSS   
Build cross-platform desktop apps with JavaScript, HTML, and CSS   
   
