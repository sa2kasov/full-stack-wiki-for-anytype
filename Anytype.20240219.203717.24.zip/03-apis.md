# 03. APIs   
[JSON APIs](json-apis.md)    
[REST](rest.md)    
[13\. GraphQL](13-graphql.md)    
