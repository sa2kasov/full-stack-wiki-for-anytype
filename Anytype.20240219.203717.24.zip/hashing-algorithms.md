# Hashing Algorithms   
[MD5](md5.md)    
[SHA](sha.md)    
[bcrypt](bcrypt.md)    
[scrypt](scrypt.md)    
