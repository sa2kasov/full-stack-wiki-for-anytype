# Linux   
[Ubuntu &amp; Debian](ubuntu-and-debian.md)    
