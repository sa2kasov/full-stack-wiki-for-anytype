# Scopes   
[Block Scope](block-scope.md)    
[Function Scope](function-scope.md)    
[Global Scope](global-scope.md)    
