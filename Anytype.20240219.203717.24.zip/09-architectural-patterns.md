# 09. Architectural Patterns   
[Monolithic Apps](monolithic-apps.md)    
[Microservices](microservices.md)    
[SOA](soa.md)    
[Serverless](serverless.md)    
[Service Mesh](service-mesh.md)    
[Twelve-Factor Apps](twelve-factor-apps.md)    
