# Mitigation Strategies   
[Graceful Degradation](graceful-degradation.md)    
[Throttling](throttling.md)    
[Backpressure](backpressure.md)    
[Load Shifting](load-shifting.md)    
[Circuit Breaker](circuit-breaker.md)    
