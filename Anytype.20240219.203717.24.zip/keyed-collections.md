# Keyed Collections   
[Map](map.md)    
[Set](set.md)    
[WeakMap](weakmap.md)    
[WeakSet](weakset.md)    
