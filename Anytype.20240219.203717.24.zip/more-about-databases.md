# More about Databases   
[ORMs](orms.md)    
[ACID](acid.md)    
[Transactions](transactions.md)    
[N+1 Problem](n-1-problem.md)    
[Normalization](normalization.md)    
[Failure Modes](failure-modes.md)    
[Profiling Performance](profiling-performance.md)    
[Scaling Databases](scaling-databases.md)    
