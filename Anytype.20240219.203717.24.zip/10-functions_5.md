# 10. Functions   
[Defining and Calling Functions](defining-and-calling-functions.md)    
[Function Parameters](function-parameters.md)    
[Arrow Functions](arrow-functions.md)    
[IIFE](iife.md)    
[arguments Object](arguments-object.md)    
[Scope &amp; Function Stack](scope-and-function-stack.md)    
[Built-in Functions](built-in-functions.md)    
