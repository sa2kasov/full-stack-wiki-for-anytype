# 18. GitOps   
[ArgoCD](argocd.md)    
