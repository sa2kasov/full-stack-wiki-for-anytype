# 06. Equality Comparisons   
[Value Comparison Operators](value-comparison-operators.md)    
[Equality Algorithms](equality-algorithms.md)    
