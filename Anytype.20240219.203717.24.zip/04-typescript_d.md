# 04. TypeScript   
[TypeScript Roadmap: Learn to become a TypeScript developer](https://roadmap.sh/typescript)    
