# Types of Scaling: Horizontal vs Vertical Scaling   
