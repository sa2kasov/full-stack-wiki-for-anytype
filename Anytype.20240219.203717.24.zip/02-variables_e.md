# 02. Variables   
[Variable Declarations](variable-declarations.md)    
[Hoisting](hoisting.md)    
[Naming Rules](naming-rules.md)    
[Scopes](scopes.md)    
