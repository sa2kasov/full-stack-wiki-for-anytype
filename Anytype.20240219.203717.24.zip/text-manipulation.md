# Text Manipulation   
