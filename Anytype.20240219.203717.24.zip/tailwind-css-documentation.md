# Tailwind CSS - Documentation   
Tailwind CSS is a utility-first CSS framework for rapidly building modern websites without ever leaving your HTML.   
