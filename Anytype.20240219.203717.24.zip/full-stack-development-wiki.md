# Full Stack Development Wiki   
[Design](design.md)    
[Frontend](frontend.md)    
[Backend](backend.md)    
[DevOps](devops.md)    
[Mobile](mobile.md)    
[Desktop](desktop.md)    
[AI](ai.md)    
[Blockchain](blockchain.md)    
   
 --- 
   
[Full Stack Developer Roadmap](https://roadmap.sh/full-stack)    
[Computer Science Roadmap: Curriculum for the self taught developer](https://roadmap.sh/computer-science)    
[Code Review - roadmap.sh](https://roadmap.sh/code-review)    
