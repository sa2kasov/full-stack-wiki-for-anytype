# Scope & Function Stack   
[Recursion](recursion.md)    
[Lexical Scoping](lexical-scoping.md)    
[Closures](closures.md)    
