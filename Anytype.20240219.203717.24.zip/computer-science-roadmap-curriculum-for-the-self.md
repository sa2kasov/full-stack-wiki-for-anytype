# Computer Science Roadmap: Curriculum for the self taught developer   
Computer Science study plan with free resources for the self-taught and bootcamp grads wanting to learn Computer Science.   
