# TypeScript Roadmap: Learn to become a TypeScript developer   
Community driven, articles, resources, guides, interview questions, quizzes for typescript development. Learn to become a modern TypeScript developer by following the steps, skills, resources and guides listed in this roadmap.   
