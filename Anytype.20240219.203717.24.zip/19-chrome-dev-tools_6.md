# 19. Chrome Dev Tools   
[Debugging Issues](debugging-issues.md)    
[Debugging Memory Leaks](debugging-memory-leaks.md)    
[Debugging Performance](debugging-performance.md)    
