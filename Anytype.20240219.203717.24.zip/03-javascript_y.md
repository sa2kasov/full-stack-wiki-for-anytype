# 03. JavaScript   
[JavaScript Developer Roadmap: Step by step guide to learn JavaScript](https://roadmap.sh/javascript)    
   
