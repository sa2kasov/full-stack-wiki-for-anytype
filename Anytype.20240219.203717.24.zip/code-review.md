# Code Review   
Learn what to review when conducting code reviews. We also have questions to ask yourself under each node of the pyramid to guide you further.   
